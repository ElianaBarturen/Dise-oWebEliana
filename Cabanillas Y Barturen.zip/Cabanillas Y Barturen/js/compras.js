$(document).ready(function () {
  mostrarCompras();
});
